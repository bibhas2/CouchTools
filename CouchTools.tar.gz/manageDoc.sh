export CLASSPATH=couchtools.jar:gson-1.7.1.jar:couchbase-client-1.2.0.jar:spymemcached-2.10.0.jar:httpcore-4.1.1.jar:httpcore-nio-4.1.1.jar:jettison-1.1.jar:netty-3.5.5.Final.jar:commons-codec-1.5.jar
java com.mobiarch.tools.ManageDoc $*
