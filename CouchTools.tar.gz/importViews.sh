export CLASSPATH=couchtools.jar:gson-1.7.1.jar
java com.mobiarch.tools.ImportViews $*